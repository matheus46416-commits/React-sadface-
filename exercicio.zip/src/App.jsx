import Header from './components/Header';
import CardFilme from './components/CardFilme';
import Categorias from './components/Categorias';

//Mock de filmes
const filmeMock = [
    {id: 278, titulo: "Um sonho de liberdade",nota: 7, ano: "1994",
    imagem: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYa3hRkjtSUwAu5Fo3-FVx4oA2S7aVCEZO6iznm2EWpw&s=10",
    sinopse: "Em 1946, Andy Dufresne (Tim Robbins), um jovem e bem sucedido banqueiro, tem a sua vida radicalmente modificada ao ser condenado por um crime que nunca cometeu, o homicídio de sua esposa e do amante dela. Ele é mandado para uma prisão que é o pesadelo de qualquer detento, a Penitenciária Estadual de Shawshank, no Maine. Lá ele irá cumprir a pena perpétua. Andy logo será apresentado a Warden Norton (Bob Gunton), o corrupto e cruel agente penitenciário, que usa a Bíblia como arma de controle e ao Capitão Byron Hadley (Clancy Brown) que trata os internos como animais. Andy faz amizade com Ellis Boyd Redding (Morgan Freeman), um prisioneiro que cumpre pena há 20 anos e controla o mercado negro da instituição."
    }, 
    {id: 238, titulo: "O poderoso chefão",nota: 7, ano: "1972",
    imagem:"https://m.media-amazon.com/images/M/MV5BYTRmMjkwYzYtYTRiMi00NDJjLTk1NjctMDA3MjY2ZWIyMGQ5XkEyXkFqcGc@._V1_.jpg",
    sinopse: "Don Vito Corleone, chefe de uma poderosa família mafiosa de Nova York, celebra o casamento de sua filha Connie enquanto atende pedidos de justiça e ajuda de seus aliados. Entre eles está Johnny Fontane, cantor que busca recuperar sua carreira com a ajuda de Vito. Enquanto isso, Michael Corleone, seu filho mais jovem e recém-chegado da Segunda Guerra Mundial, tenta manter distância dos negócios da família. Porém, quando o mafioso Sollozzo propõe a Vito uma parceria para o tráfico de drogas, sua recusa desencadeia uma violenta disputa entre as famílias criminosas de Nova York."
    }, 
    {id: 328, titulo: "Drive",nota: 8.7, ano: "2012",
    imagem:"https://m.media-amazon.com/images/I/615ot6U8mgL._AC_UF894,1000_QL80_.jpg",
    sinopse: "Durante o dia um motorista (Ryan Gosling) trabalha como mecânico e dublê em filmes de Hollywood, enquanto que à noite ele presta serviços para a máfia. Ele é vizinho de Irene (Carey Mulligan), que é casada e tem um filho com Standard (Oscar Isaac). Percebendo a situação difícil de Standard, que saiu há pouco tempo da prisão, o motorista o convida para realizar um assalto. Só que o golpe dá errado, o que coloca em risco as vidas do motorista, Irene e seu filho."
    },
    {id: 596, titulo: "Mulher nota mil",nota: 10, ano: "1985",
    imagem:"https://br.web.img3.acsta.net/c_310_420/medias/nmedia/18/87/11/03/19872113.jpg",
    sinopse: 'Gary Wallace (Anthony Michael Hall) e Wyatt Donnelly (Ilan Mitchell-Smith) são dois adolescentes nada populares com o sexo oposto. Eles resolvem criar no computador de Wyatt a mulher que eles acreditam ser a ideal. Ua tempestade dá vida a ela, que é "batizada" como Lisa (Kelly LeBrock), que é sexy, bonita, determinada, desejada por todos, fiel aos seus criadores, mas com um modo de ser que deixa todos que cruzam o seu caminho desconcertados. Entretanto problemas começam a ocorrer quando o implicante Chet (Bill Paxton), o irmão mais velho de Wyatt, sente que algo está estranho.'
    }, 
    {id: 873, titulo: "Sherlock Holmes: O Jogo de Sombras",nota: 7, ano: "2011",
    imagem:"https://br.web.img3.acsta.net/medias/nmedia/18/87/34/84/20028738.jpg",
    sinopse: "Sherlock Holmes (Robert Downey Jr.) continua desenvolvendo novos disfarces e maneiras de ludibriar seus oponentes, enquanto seu fiel escudeiro John Watson (Jude Law) está prestes a se casar e sair numa lua de mel dos sonhos com sua amada Mary Morstan (Kelly Reilly). A única coisa que o caro Watson não contava era que seu amigo Holmes apareceria com uma nova teoria conspiratória de que o ardiloso Professor Moriarty (Jarred Harris) estaria por trás de uma série de assassinatos, que visam desestabilizar a paz mundial. Quando a amiga Irene Adler (Rachel McAdams) desaparece, depois de prestar um serviço sujo para Moriarty, Holmes descobre que a cigana Simza (Noomi Rapace) pode ser a chave para desvendar todo o mistério por trás das mortes. A questão é: conseguirá Holmes superar a esperteza do terrível Moriarty? Assista ao filme"
    }, 
    {id: 436, titulo: "Sem Licença para Dirigir",nota: 9, ano: "1988",
    imagem:"https://br.web.img3.acsta.net/pictures/15/06/10/16/24/450099.jpg",
    sinopse: "Les (Corey Haim) é um adolescente tentando aprender como dirigir e chamar a atenção de Mercedes (Heather Graham), uma garota popular do colégio. Les consegue um encontro com a garota e, para imprecioná-la, decide dirigir, mesmo não tendo uma licensa. Além de ir para o encontro sem a permissão dos pais, Les ainda pega emprestado o estimado carro do avô, um Cadillac. Trailers"
    } 
  ];

function App() {

  return (
    <>
      <div className="min-h-screen bg-zinc-800 p-4 text-white font-sans">
        {/* Header fixo */}
        <Header/>
        {/* Area principal (onde os componentes ficarão no futuro)*/}
        <main className="container mx-auto p-4 mt-8">
          <h2 className="font-bold text-[25px]">Em destaque</h2>
          {/* Container flexivel */}
          <div className="flex flex-wrap gap-6 pt-5">
            {/* Abertura das chaves para o map */}
            {filmeMock.map((filmeAtual) => (
              <CardFilme
               key={filmeAtual.id}
               filme={filmeAtual}
              />
            ))}
          </div>
          <Categorias/>
        </main>
      </div>
    </>
  )
}

export default App
