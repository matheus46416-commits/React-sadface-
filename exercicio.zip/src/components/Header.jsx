function Header(){
    return(
<header className="bg-zinc-900 p-4 shadow-md sticky top-0 z-50">
          <div className="container mx-auto flex justify-between items-center">
            <h1 className="text-3x1 font-bold text-yellow-400">🎞️ FIEC Catálogo</h1>
            <nav>
              <ul className="flex space-x-6 text-gray-300">
                <li className="hover:text-white">Inicio</li>
                <li className="hover:text-white">Em Alta</li>
              </ul>
            </nav>
          </div>
        </header>);
}

export default Header;