import React from "react";

const CardFilme = ({ filme : {titulo,imagem,nota,sinopse}} ) => {
    return (<div className="bg-zinc-900 border-zin-800 rounded-xl overflow-hidden shadow-lg
     hover:border-blue-500 transition-all duration-300 flex 
     flex-col h-100 w-50">
        <img src={imagem} alt={`Poster do filme ${titulo}`} />
        {nota < 8.5 ? <span className="bg-yellow-500 text-black font-bold px-2 py-1 rounded text-xs"> ⭐  {nota}</span>
        : <span className="bg-green-500 text-black font-bold px-2 py-1 rounded text-xs"> ⭐  {nota}</span>}
        <div>
         <p>{sinopse}</p>
        </div>
     </div>);
};
export default CardFilme;